﻿using Prj_WMS.ViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls;


namespace Prj_WMS
{
    /// <summary>
    /// UserControlMenuItem.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UserControlMenuItem : UserControl
    {
        MainWindow _context;

        public UserControlMenuItem(ItemMenu itemMenu, MainWindow context)
        {
            InitializeComponent();
            this._context = context;

            ExpanderMenu.Visibility = itemMenu.SubItems == null ? Visibility.Collapsed : Visibility.Visible;
            ListViewItemMenu.Visibility = itemMenu.SubItems == null ? Visibility.Visible : Visibility.Collapsed;
            //this.itemMenu = itemMenu;
            this.DataContext = itemMenu;
        }

       


        //Click 이벤트로 옮김
        private void ListViewMenu_SelectionChanged(object sender, MouseButtonEventArgs e)
        {
            try
            {
                //20201028 귀찮아서 때려박음 ㅋㅋ ㄹㅃㅃ
                //string str_name = ((SubItem)((ListView)sender).SelectedItem).Name;
                //if (str_name == "모니터링")
                //{
                //    Window_Monitoring window_Monitoring = new Window_Monitoring();
                //    window_Monitoring.Show();

                //    return;
                //}

                Drgablz_Main_TabItem tmp_drag_able_tabitem = new Drgablz_Main_TabItem(((SubItem)((ListView)sender).SelectedItem).Name, ((SubItem)((ListView)sender).SelectedItem).Screen);

                List<Drgablz_Main_TabItem> CheckItems = new List<Drgablz_Main_TabItem>();
                CheckItems = _context.Main_TabItems;

                bool isAlreadyInsert = false;

                for (int i = 0; i < CheckItems.Count; i++)
                {
                    if (CheckItems[i]._Main_Binding_Item == ((SubItem)((ListView)sender).SelectedItem).Screen)
                    {
                        isAlreadyInsert = true;
                        break;
                    }


                }


                bool isNew = true;
                for (int i = 0; i < _context.TabControl_Main.Items.Count; i++)
                {
                    var var_tmp = (TabItem)_context.TabControl_Main.Items[i];

                    if (var_tmp.Header.ToString() == tmp_drag_able_tabitem.Header_TEXT)
                    {
                        isNew = false;
                        break;
                    }



                }

                if (isNew)
                {
                    if (!isAlreadyInsert && ((SubItem)((ListView)sender).SelectedItem).Screen != null)
                    {
                        _context.Main_TabItems.Add(tmp_drag_able_tabitem);
                        _context.TabMenuAdd(tmp_drag_able_tabitem.MyTab);
                    }
                    _context.TabMenuSelect(tmp_drag_able_tabitem.MyTab);
                }
                else
                {
                    for (int i = 0; i < _context.TabControl_Main.Items.Count; i++)
                    {
                        var var_tmp = (TabItem)_context.TabControl_Main.Items[i];

                        if (var_tmp.Header.ToString() == tmp_drag_able_tabitem.Header_TEXT)
                        {
                            _context.TabMenuSelect(var_tmp);

                            break;
                        }



                    }
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            //
        }

    }
}
