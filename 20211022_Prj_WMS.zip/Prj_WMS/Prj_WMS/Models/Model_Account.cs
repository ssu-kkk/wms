﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prj_WMS.Models
{
    public class Model_Account
    {

        public Model_Account(string id, string account_id, string account_paswd, string account_staff_id, string account_make_date)
        {
            this.id = id;
            this.account_id = account_id;
            this.account_passwd = account_paswd;
            this.account_staff_id = account_staff_id;
            this.account_make_date = account_make_date;

        }

        public string id { get; set; }

        public string account_id { get; set; }

        public string account_passwd { get; set; } 

        public string account_staff_id { get; set; }

        public string account_make_date { get; set; }


    }
}
