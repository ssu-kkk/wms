﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prj_WMS.Models
{
    public class Model_Product
    {

        public Model_Product(string id, string product_type_name, string product_code, 
            string product_name, string trade_name, string product_now_count, string product_comment)
        {
            this.id = id;
            this.product_type_name = product_type_name;
            this.product_code = product_code;
            this.product_name = product_name;
            this.trade_name = trade_name;
            this.product_now_count = product_now_count;
            this.product_comment = product_comment;

        }

        public string id { get; set; }

        public string product_type_name { get; set; }

        public string product_code { get; set; }

        public string product_name { get; set; }

        public string trade_name { get; set; }

        public string product_now_count { get; set; }

        public string product_comment { get; set; }

    }
}
