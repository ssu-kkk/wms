﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prj_WMS.Models
{
    public class Model_Trade
    {


        public Model_Trade(string id, string trade_name, string trade_fax, string trade_addr, 
            string trade_call, string trade_phone, string trade_admin, string trade_number, string location_name, string trade_type_name, string trade_comment)
        {
            this.id = id;

            this.trade_name = trade_name;

            this.trade_fax = trade_fax;

            this.trade_addr = trade_addr;

            this.trade_call = trade_call;

            this.trade_phone = trade_phone;

            this.trade_admin = trade_admin;

            this.trade_number = trade_number;

            this.location_name = location_name;

            this.trade_type_name = trade_type_name;

            this.trade_comment = trade_comment;

        }



        public string id { get; set; }

        public string trade_name { get; set; }

        public string trade_fax { get; set; }
        
        public string trade_addr { get; set; }

        public string trade_call { get; set; }

        public string trade_phone { get; set; }

        public string trade_admin { get; set; }

        public string trade_number { get; set; }

        public string location_name { get; set; }

        public string trade_type_name { get; set; }

        public string trade_comment { get; set; }



    }
}
