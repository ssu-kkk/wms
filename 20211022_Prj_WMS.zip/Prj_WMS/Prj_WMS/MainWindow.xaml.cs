﻿using MaterialDesignThemes.Wpf;
using Prj_WMS.Functions;
using Prj_WMS.Screens;
using Prj_WMS.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prj_WMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public List<Drgablz_Main_TabItem> Main_TabItems = new List<Drgablz_Main_TabItem>();


        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal,
                                                        int size, string filePath);


        public static StringBuilder global_ret_ip = new StringBuilder();

        public static StringBuilder global_ret_port = new StringBuilder();


        public MainWindow()
        {
            InitializeComponent();

            INIT_SOCKET();


            INIT_SERVER();

            //Main_logo.Source = 
            //img.Source = new BitmapImage(new Uri(@"E:\Cs\Image\1.png", UriKind.Absolute));

            var Menu_Product_Info = new List<SubItem>();
            var item_Menu_Product = new ItemMenu("제품정보", Menu_Product_Info, PackIconKind.None);
            Menu_Product_Info.Add(new SubItem("제품정보", new uC_Product_Info()));
            Menu.Children.Add(new UserControlMenuItem(item_Menu_Product, this));


            var Menu_Product_Info_Input = new List<SubItem>();
            var item_Menu_Product_Info_Input = new ItemMenu("입/출고이력", Menu_Product_Info_Input, PackIconKind.None);
            Menu_Product_Info_Input.Add(new SubItem("입고이력", new uC_Prouduct_input()));
            Menu_Product_Info_Input.Add(new SubItem("출고이력", new uC_Product_output()));
            Menu.Children.Add(new UserControlMenuItem(item_Menu_Product_Info_Input, this));


            var Menu_Product_Info_Cancel = new List<SubItem>();
            var item_Menu_Product_Info_Cancel = new ItemMenu("취소이력", Menu_Product_Info_Cancel, PackIconKind.None);
            Menu_Product_Info_Cancel.Add(new SubItem("입고취소내역", new uC_Product_Input_Cancel()));
            Menu_Product_Info_Cancel.Add(new SubItem("출고취소내역", new uC_Product_Output_Cancel()));
            Menu.Children.Add(new UserControlMenuItem(item_Menu_Product_Info_Cancel, this));


            var Menu_Trade_Info = new List<SubItem>();
            var item_Menu_Trade_Info = new ItemMenu("거래처관리", Menu_Trade_Info, PackIconKind.None);
            Menu_Trade_Info.Add(new SubItem("거래처관리", new uC_Trade_Info()));
            Menu.Children.Add(new UserControlMenuItem(item_Menu_Trade_Info, this));


            this.DataContext = Main_TabItems;


        }

        void INIT_SOCKET()
        {
            StringBuilder ret_ip = new StringBuilder();
            StringBuilder ret_port = new StringBuilder();

            global_ret_ip = new StringBuilder();
            global_ret_port = new StringBuilder();

            
            var soc_file_Path = AppDomain.CurrentDomain.BaseDirectory + @"fac_ini" + @"\sock_config.ini";
            string file_path = soc_file_Path.ToString();

            GetPrivateProfileString("LOGIN", "IP", "(NONE)", ret_ip, 32, file_path);
            GetPrivateProfileString("LOGIN", "PORT", "(NONE)", ret_port, 32, file_path);

            Console.WriteLine(ret_ip.ToString());
            Console.WriteLine(ret_port.ToString());

            string s_ret_ip = ret_ip.ToString();
            string s_ret_port = ret_port.ToString();


            Func_Socket.sock_connect(s_ret_ip, s_ret_port);

         
        }

        //var filePath = AppDomain.CurrentDomain.BaseDirectory + @"fac_ini" + @"\pop_config.ini";

        void INIT_SERVER()
        {
            StringBuilder ret_id = new StringBuilder();
            StringBuilder ret_pw = new StringBuilder();
            StringBuilder ret_server = new StringBuilder();
            StringBuilder ret_path = new StringBuilder();
            StringBuilder ret_port = new StringBuilder();
            StringBuilder ret_WEB_IP = new StringBuilder();
            StringBuilder ret_WEB_Port = new StringBuilder();

            //img.Source = new BitmapImage(new Uri(@"E:\Cs\Image\1.png", UriKind.Absolute));
            Main_logo.Source = new BitmapImage(new Uri(AppDomain.CurrentDomain.BaseDirectory + @"logo" + @"\v_logo.png", UriKind.Absolute));


            var va_file_Path = AppDomain.CurrentDomain.BaseDirectory + @"fac_ini" + @"\pop_config.ini";
            string file_path = va_file_Path.ToString();
            
            //string file_path = @"C:\cleaning_config\cleaning_config.ini";
            //ini 읽기
            GetPrivateProfileString("LOGIN", "DB_ID", "(NONE)", ret_id, 32, file_path);
            GetPrivateProfileString("LOGIN", "DB_PASSSWD", "(NONE)", ret_pw, 32, file_path);
            GetPrivateProfileString("LOGIN", "DB_IP", "(NONE)", ret_server, 32, file_path);
            GetPrivateProfileString("LOGIN", "File_PATH", "(NONE)", ret_path, 32, file_path);
            GetPrivateProfileString("LOGIN", "DB_Port", "(NONE)", ret_port, 32, file_path);
            GetPrivateProfileString("LOGIN", "WEB_IP", "(NONE)", ret_WEB_IP, 32, file_path);
            GetPrivateProfileString("LOGIN", "WEB_Port", "(NONE)", ret_WEB_Port, 32, file_path);

            //SERVER_IP = ret_server.ToString();
            //DB_ID = ret_id.ToString();
            //DB_PASSSWD = ret_pw.ToString();
            //File_PATH = ret_path.ToString();
            global_variable.MariaDB.IP = ret_server.ToString();
            global_variable.MariaDB.ID = ret_id.ToString();
            global_variable.MariaDB.Passwd = ret_pw.ToString();
            global_variable.MariaDB.Port = ret_port.ToString();

            //string strport = "";// ":1234";
            //global_variable.PHP.IP = global_variable.MariaDB.IP; 191126 local
            global_variable.PHP.Port = ret_WEB_Port.ToString();
            global_variable.PHP.IP = ret_WEB_IP.ToString() + ":" + global_variable.PHP.Port;// global_variable.MariaDB.IP;// strport;
            global_variable.PHP.Folder = "orderimg";


            bool Check_DB_Connect = !DBConnect(global_variable.MariaDB.IP, "yourock_scm_db", global_variable.MariaDB.ID, global_variable.MariaDB.Passwd, global_variable.MariaDB.Port);
            if (Check_DB_Connect)
            {
                MessageBox.Show(" DB 서버에 연결할 수 없습니다. 설정을 확인해주세요.");

                Environment.Exit(0);
                System.Diagnostics.Process.GetCurrentProcess().Kill();
                this.Close();
                return;

            }
            //bool DBConnectCheck = DBConnect("192.168.1.105", "smartfactory_db", "root", "1qaz2wsx", "3306");
        }



        bool DBConnect(string ServerIP, string strDBName, string strUserID, string strPasswd, string strPort)
        {
            try
            {


                return Func_MySQL.instance.Connect(ServerIP, strDBName, strUserID, strPasswd, strPort);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }

        }


        void sockect_connect()
        {
            string ip = "127.0.0.1";
            int port_num = 998;



        }


        //function
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            double screenWidth = GridMain.Width;
            double screenHeight = GridMain.Height;

            Console.WriteLine("screenWidth : " + screenWidth);
            Console.WriteLine("screenHeight : " + screenHeight);
        }

        internal void SwitchScreen(object sender)
        {
            var screen = ((UserControl)sender);

            if (screen != null)
            {

                GridMain.Children.Clear();
                GridMain.Children.Add(screen);

            }
        }

        public void TabMenuAdd(TabItem tmp_tabItem)
        {
            TabControl_Main.Items.Add(tmp_tabItem);
        }
        public void TabMenuSelect(TabItem tmp_tabItem)
        {
            TabControl_Main.SelectedValue = tmp_tabItem;
        }

        private void Button_Click_Exit(object sender, RoutedEventArgs e)
        {

            //Func_Socket.sock_disconnect();


            if (Func_Util.YesOrNoMSGBOX("종료", "프로그램을 종료하시겠습니까?"))
            {
                // MessageBox.Show("종료하겠습니다");
                Environment.Exit(0);

            }


         
        }

        private void togle_menu_Click(object sender, RoutedEventArgs e)
        {

            bool togleMenuChekced = (bool)togle_menu.IsChecked;
            if (togleMenuChekced)
            {
                colMenu.Width = new GridLength(250);
            }
            else
            {
                colMenu.Width = new GridLength(0);
            }
        }


        private void btn_refresh_test(object sender, MouseButtonEventArgs e)
        {
            //TabControl_Main.i
        }
    }
}
