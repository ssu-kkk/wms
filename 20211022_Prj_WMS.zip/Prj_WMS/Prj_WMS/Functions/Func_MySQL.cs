﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;


namespace Prj_WMS.Functions
{
    class Func_MySQL
    {


        static Func_MySQL _instance;

        public static Func_MySQL instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Func_MySQL();
                return _instance;

            }
        }



        public MySqlCommand SetDATA(string strQuery)
        {
            MySqlCommand _mySqlCommand = new MySqlCommand(strQuery, Conn);
            return _mySqlCommand;

        }

        public DataTable GetDATA(string strquery)
        {
            DataTable dt = new DataTable();
            try
            {
                strquery = strquery + ";";
                //   MySqlCommand mySqlCommand = new MySqlCommand(strquery, Conn);


                using (var _connection = new MySqlConnection(ConnectINFO))
                {
                    _connection.Open();
                    using (var cmd = new MySqlCommand(strquery, _connection))
                    {
                        using (var reader = cmd.ExecuteReader())
                        {
                            dt.Load(reader);
                        }
                    }
                }

                Console.WriteLine("[" + DateTime.Now.ToString() + "]" + strquery + " : OK");
            }
            catch (Exception ex)
            {
                
                Console.WriteLine(ex.ToString());
                Console.WriteLine("MS [ " + ex.ToString() + "]");
                //Messagebox.show()

            }

            return dt;
        }


        public static MySqlConnection Conn { get; set; }
        // private static string mysql_conn_str = "Server=local;Database=testdb;Uid=root;Pwd=1qaz2wsx;Charset=utf8";
        public static string ConnectINFO { get; set; }

        public bool Connect(string strserverIP, string strDBName, string strUserID, string strPasswd, string strPort)
        {
            ConnectINFO = "Server=" + strserverIP + "; Database=" + strDBName + ";Uid=" + strUserID + 
                ";Pwd=" + strPasswd + ";Charset=utf8; port=" + strPort + ";" +
                "Allow User Variables=True";

            bool isConnect = false;
            Conn = new MySqlConnection(ConnectINFO);

            try
            {
                Conn.Open();
                isConnect = true;
                return isConnect;

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.ToString());
                isConnect = false;
                return isConnect;
            }
        }

        public bool DisConnect()
        {
            bool isDisConnect = false;
            try
            {
                Conn.Close();
                Console.WriteLine("============DisConnect============");
                isDisConnect = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                isDisConnect = false;
                Console.WriteLine("============DisConnect============");
            }
            return isDisConnect;
        }



        /// <summary>
        /// itype = 0 ,숫자 | Op1 _ 연산지1 | Op2 연산자2
        /// </summary>
        /// <param name="itype">0 ''안붙임</param>
        /// <param name="str_colname">해당 컬럼 이름 </param>
        /// <param name="str_value">값</param>
        /// <param name="Operator_1">연산자 and or 등</param>
        /// <param name="Operator_2">연산자 and or 등</param>
        /// <returns></returns>
        public string GetWhereSQL(int itype,
            string str_colname,
            string str_value,
            string Operator_1 = "",
            string Operator_2 = ""
            )
        {
            string str_where_return = "";


            if (string.IsNullOrEmpty(str_value))
            {
                return "";
            }

            if (Operator_1 == "like")
            {
                str_value = "%" + str_value + "%";
            }

            if (itype != 0)
            {
                str_value = "'" + str_value + "'";
            }

            str_where_return = str_colname +
                " " + Operator_1 + " "
                + str_value + " "
                + Operator_2 + " ";


            return str_where_return;

        }

    }
}
