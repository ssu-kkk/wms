﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace Prj_WMS.Functions
{
    class Func_Util
    {

        public static bool YesOrNoMSGBOX(string Title, string Content)
        {
            bool returnbool = false;
            MessageBoxResult result = MessageBox.Show(Content, Title, MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {

                return true;
            }
            else
            {
                return false;
            }


        }

    }
}
