﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace Prj_WMS.Functions
{
    class Func_Socket
    {

        static bool isConnected = false;

        //소켓 
        static Socket client_socket; //소켓 선언
       // bool isConnected; // bool로 서버와 클라이언트가 연결되었는지 판단 
        static byte[] bytes = new byte[1024];
        static string data; // 글자 데이터를 읽고 불러오는대 선언

        const char STX = (char)0x02; // stx
        const char ETX = (char)0x03; // etx


        static Func_Socket _instance;

        public static Func_Socket instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Func_Socket();

                return _instance;

            }
        }



        public static void sock_connect(string ip, string portnum)
        {

            try
            {
                if (isConnected == true)
                    return;


                int port_number = Convert.ToInt32(portnum.Replace(" ", ""));

                client_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                client_socket.Connect(new IPEndPoint(IPAddress.Parse(ip), port_number));
                //MessageBox.Show("소켓 연결");
                isConnected = true;
                Thread listen_thread = new Thread(do_receive1);
                listen_thread.Start();

            }
            catch(Exception ex)
            {
                MessageBox.Show("소켓서버를 확인해주세요. ");
                Console.WriteLine(ex.ToString());


                Environment.Exit(0);
                System.Diagnostics.Process.GetCurrentProcess().Kill();
                //this.Close();
                return;



            }


        }


        public static void sock_disconnect()
        {
            //client_socket.Close();

            client_socket.Shutdown(SocketShutdown.Both);
            client_socket.Disconnect(true);

        }


        //쓰레드 걍 static 때려박아 ㅋㅋ ㄹㅃㅃ 
        public static void do_receive()
        {
            while (isConnected)
            {
                while (true)
                {
                    byte[] bytes = new byte[7];
                    int bytesRec = client_socket.Receive(bytes);

                    byte stx_tmp = Convert.ToByte(STX);
                    byte etx_tmp = Convert.ToByte(ETX);

                    if (bytes[0].Equals(stx_tmp))
                    {
                        byte[] cul_bytes = new byte[4];

                        for (int i = 0; i < cul_bytes.Length; i++)
                        {

                            cul_bytes[i] = bytes[i + 1];


                        }

                        data += Encoding.UTF8.GetString(cul_bytes, 0, cul_bytes.Length);

                    }
                    else
                    {

                        byte[] cul_bytes = new byte[4];
                        for (int i = 0; i < cul_bytes.Length; i++)
                        {
                            cul_bytes[i] = bytes[i + 1];

                        }
                        data += Encoding.UTF8.GetString(cul_bytes, 0, cul_bytes.Length);

                    }
                    data = data.Substring(0, data.Length);
                    Console.WriteLine(data);

                    //Invoke((MethodInvoker)delegate
                    //{
                    //    listBox1.Items.Add(data);
                    //}
                    //);

                    data = "";
                }
            }
        }

        public static void do_receive1()
        {
            while (isConnected)
            {
                while (true)
                {
                    var data = Encoding.UTF8.GetBytes("");
                    // 데이터의 길이를 수신하기 위한 배열을 생성한다. (4byte)
                    data = new byte[4];
                    // 데이터의 길이를 수신한다.
                    client_socket.Receive(data, data.Length, SocketFlags.None);
                    // server에서 big엔디언으로 전송을 했는데도 little 엔디언으로 온다. big엔디언과 little엔디언은 배열의 순서가 반대이므로 reverse한다.
                    Array.Reverse(data);
                    // 데이터의 길이만큼 byte 배열을 생성한다.
                    data = new byte[BitConverter.ToInt32(data, 0)];
                    // 데이터를 수신한다.
                    client_socket.Receive(data, data.Length, SocketFlags.None);
                    // 수신된 데이터를 UTF8인코딩으로 string 타입으로 변환 후에 콘솔에 출력한다.
                    Console.WriteLine(Encoding.UTF8.GetString(data));


                }
            }
        }

        public void send_msg(string text)
        {

            if (isConnected == false)
                return;

            try
            {
                byte[] msg = Encoding.UTF8.GetBytes(text);
                int byteSent = client_socket.Send(msg);

                text = "";
            }
            catch(Exception ex)
            {
                MessageBox.Show("데이터전송오류 " + ex.ToString());

            }
        }

        public void send_msg1(string text)
        {
            
            if(isConnected == false)
            {
                return;

            }
            try
            {
                var data = Encoding.UTF8.GetBytes(text);
                client_socket.Send(BitConverter.GetBytes(data.Length));

                client_socket.Send(data);

                //client_socket.Close();

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
        }

        public static void sc_write()
        {
            // 소켓을 생성한다.
            using (Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
            {
                // Connect 함수로 로컬(127.0.0.1)의 포트 번호 9999로 대기 중인 socket에 접속한다.
                client.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9999));
                // 보낼 메시지를 UTF8타입의 byte 배열로 변환한다.
                var data = Encoding.UTF8.GetBytes("this message is sent from C# client.");
                // big엔디언으로 데이터 길이를 변환하고 서버로 보낼 데이터의 길이를 보낸다. (4byte)
                client.Send(BitConverter.GetBytes(data.Length));
                // 데이터를 전송한다.
                client.Send(data);
                // 데이터의 길이를 수신하기 위한 배열을 생성한다. (4byte)
                data = new byte[4];
                // 데이터의 길이를 수신한다.
                client.Receive(data, data.Length, SocketFlags.None);
                // server에서 big엔디언으로 전송을 했는데도 little 엔디언으로 온다. big엔디언과 little엔디언은 배열의 순서가 반대이므로 reverse한다.
                Array.Reverse(data);
                // 데이터의 길이만큼 byte 배열을 생성한다.
                data = new byte[BitConverter.ToInt32(data, 0)];
                // 데이터를 수신한다.
                client.Receive(data, data.Length, SocketFlags.None);
                // 수신된 데이터를 UTF8인코딩으로 string 타입으로 변환 후에 콘솔에 출력한다.
                Console.WriteLine(Encoding.UTF8.GetString(data));
            }
            Console.WriteLine("Press any key...");
            Console.ReadLine();

        }


    }
}
