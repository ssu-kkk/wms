﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prj_WMS.Functions
{
    class global_variable
    {

        public struct MariaDB
        {
            public static string IP { get; set; }
            public static string ID { get; set; }
            public static string Passwd { get; set; }
            public static string Port { get; set; }

        }

        public struct PHP
        {
            public static string IP { get; set; }
            public static string Folder { get; set; }

            public static string IMGaddr { get; set; }
            public static string Port { get; set; }
        }

        public struct SOCKET
        {
            public static string IP { get; set; }
            public static string PORT { get; set; }
        }

    }
}
