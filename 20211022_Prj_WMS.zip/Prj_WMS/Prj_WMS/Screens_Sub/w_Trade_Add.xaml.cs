﻿using Prj_WMS.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prj_WMS.Screens_Sub
{
    /// <summary>
    /// w_Trade_Add.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class w_Trade_Add : Window
    {
        string str_id = "";

        public string Selected_Process = "";

        public w_Trade_Add()
        {
            InitializeComponent();

            SET_CMB();

        }

        void SET_CMB()
        {
            try
            {
                string get_type_sql = "select trade_type_name from trade_info_type";
                DataTable DT_type_type = Func_MySQL.instance.GetDATA(get_type_sql);

                List<string> type_list = new List<string>();

                for (int i = 0; i < DT_type_type.Rows.Count; i++)
                {
                    type_list.Add(DT_type_type.Rows[i]["trade_type_name"].ToString());
                }
                cmb_type.ItemsSource = type_list;
                cmb_type.SelectedIndex = 0;


                string get_location_sql = "select location_name from location_info";
                DataTable DT_location = Func_MySQL.instance.GetDATA(get_location_sql);

                List<string> location_list = new List<string>();

                for (int i = 0; i < DT_location.Rows.Count; i++)
                {
                    location_list.Add(DT_location.Rows[i]["location_name"].ToString());
                }
                cmb_location.ItemsSource = location_list;

                cmb_location.SelectedIndex = 0;

            }
            catch (Exception ex)
            {

            }
        }

        private void btn_close_click(object sender, RoutedEventArgs e)
        {
            this.Close();

        }



        private void btn_save_click(object sender, RoutedEventArgs e)
        {
            SaveData();

        }


        void SaveData()
        {

            string str_dot = ",";
            var Colmun_builder = new StringBuilder();
            var Value_builder = new StringBuilder();


            int selected_type = 0;
            int selected_location = 0;


            selected_type = cmb_type.SelectedIndex;
            selected_location = cmb_location.SelectedIndex;




            //2021_08_02 KHJ
            string selected_name = cmb_location.SelectedItem.ToString();
            string location_id = "(select id from location_info where location_name = '" + selected_name + "')";
            


            Colmun_builder.Append("id" + str_dot); Value_builder.Append("default" + str_dot);
            Colmun_builder.Append("trade_name" + str_dot); Value_builder.Append("'" + txt_trade_name.Text + "'" + str_dot);
            Colmun_builder.Append("trade_fax" + str_dot); Value_builder.Append("'" + txt_trade_fax.Text + "'" + str_dot);
            Colmun_builder.Append("trade_addr" + str_dot); Value_builder.Append("'" + txt_trade_addr.Text + "'" + str_dot);
            Colmun_builder.Append("trade_call" + str_dot); Value_builder.Append("'" + txt_trade_call.Text + "'" + str_dot);
            Colmun_builder.Append("trade_phone" + str_dot); Value_builder.Append("'" + txt_trade_phone.Text + "'" + str_dot);
            Colmun_builder.Append("trade_admin" + str_dot); Value_builder.Append("'" + txt_trade_admin.Text + "'" + str_dot);
            Colmun_builder.Append("trade_type_id" + str_dot); Value_builder.Append(selected_type.ToString() + str_dot);
            //Colmun_builder.Append("trade_location_id" + str_dot); Value_builder.Append(selected_location + str_dot);
            Colmun_builder.Append("trade_location_id" + str_dot); Value_builder.Append(location_id + str_dot);
            Colmun_builder.Append("trade_number" + str_dot); Value_builder.Append("'" + txt_trade_number.Text + "'" + str_dot);
            Colmun_builder.Append("trade_comment"); Value_builder.Append("'" + txt_comment.Text + "'");




            string Worklist_SAVE_SQL = "insert into trade_info " +
         "(" + Colmun_builder.ToString() + ") values" +
         "(" + Value_builder.ToString() + ");";

            //데이터전송
            Func_MySQL.instance.SetDATA(Worklist_SAVE_SQL).ExecuteNonQuery();


            MessageBox.Show("저장되었습니다");

            //SET_CMB();

            this.Close();



        }


    }
}
