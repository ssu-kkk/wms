﻿using Prj_WMS.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prj_WMS.Screens_Sub
{
    /// <summary>
    /// W_Trade_Edit.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class W_Trade_Edit : Window
    {

        string get_trade_id = "";


        //변수값
        string id;
        string trade_name;
        string trade_addr;
        string trade_call;
        string trade_phone;
        string trade_admin;
        string trade_number;
        string trade_location_id;
        string trade_fax;
        string trade_type_id;
        string trade_comment;
        string trade_type_name;
        string location_name;


        public W_Trade_Edit(string get_trade_id = "")
        {
            InitializeComponent();

            this.get_trade_id = get_trade_id;


            SET_CMB();

            ControlSET(get_trade_id);

        }


        void SET_CMB()
        {
            try
            {
                string get_trade_type_sql = "select trade_type_name from trade_info_type";

                DataTable DT_trade_type = Func_MySQL.instance.GetDATA(get_trade_type_sql);

                List<string> type_list = new List<string>();

                for (int i = 0; i < DT_trade_type.Rows.Count; i++) 
                {

                    type_list.Add(DT_trade_type.Rows[i]["trade_type_name"].ToString());

                }
                cmb_type.ItemsSource = type_list;

                string get_location_sql = "select location_name from location_info";
                DataTable DT_location = Func_MySQL.instance.GetDATA(get_location_sql);

                List<string> location_list = new List<string>();

                for (int i = 0; i < DT_location.Rows.Count; i++)
                {
                    location_list.Add(DT_location.Rows[i]["location_name"].ToString());
                }
                cmb_location.ItemsSource = location_list;

                cmb_location.SelectedIndex = 0;


            }
            catch(Exception ex)
            {

            }
        }

        void ControlSET(string trade_id)
        {
            string sql = "select trade_info.id, " +
                "trade_name, " +
                "trade_addr, " +
                "trade_call, " +
                "trade_phone, " +
                "trade_admin, " +
                "trade_number, " +
                "trade_location_id, " +
                "trade_fax, " +
                "trade_type_id, " +
                "trade_comment, " +
                "trade_info_type.trade_type_name, " +
                "location_info.location_name " +
                " from trade_info " +
                "left outer join trade_info_type on trade_type_id = trade_info_type.id " +
                "left outer join location_info on trade_location_id " +
                "= location_info.id where trade_info.id = " + trade_id;

            DataTable DT = Func_MySQL.instance.GetDATA(sql);

            if(DT.Rows.Count != 0)
            {
                id = DT.Rows[0]["id"].ToString();
                trade_name = DT.Rows[0]["trade_name"].ToString();
                trade_addr = DT.Rows[0]["trade_addr"].ToString();
                trade_call = DT.Rows[0]["trade_call"].ToString();
                trade_phone = DT.Rows[0]["trade_phone"].ToString();
                trade_admin = DT.Rows[0]["trade_admin"].ToString();
                trade_number = DT.Rows[0]["trade_number"].ToString();
                trade_location_id = DT.Rows[0]["trade_location_id"].ToString();
                trade_fax = DT.Rows[0]["trade_fax"].ToString();
                trade_type_id = DT.Rows[0]["trade_type_id"].ToString();
                trade_comment = DT.Rows[0]["trade_comment"].ToString();
                trade_type_name = DT.Rows[0]["trade_type_name"].ToString();
                location_name = DT.Rows[0]["location_name"].ToString();


                cmb_type.SelectedItem = trade_type_name;
                txt_trade_name.Text = trade_name;
                txt_trade_addr.Text = trade_addr;
                txt_trade_call.Text = trade_call;
                txt_trade_phone.Text = trade_phone;
                txt_trade_admin.Text = trade_admin;
                txt_trade_number.Text = trade_number;
                cmb_location.SelectedItem = location_name;
                txt_trade_fax.Text = trade_fax;
                txt_comment.Text = trade_comment;


            }
        }

        void edit_save()
        {
            var str_dot = ", ";

            var Column_builder = new StringBuilder();
            var Value_builder = new StringBuilder();


            int selected_type = cmb_type.SelectedIndex + 1;

            int loc_selected_type = cmb_location.SelectedIndex + 1;


            if(Func_Util.YesOrNoMSGBOX("거래처수정", "거래처 정보를 수정하시겠습니까?"))
            {
                Column_builder.Append("trade_type_id = '" + selected_type.ToString() + "'" + str_dot);
                Column_builder.Append("trade_name = '" + txt_trade_name.Text.ToString() + "'" + str_dot);
                Column_builder.Append("trade_addr = '" + txt_trade_addr.Text.ToString() + "'" + str_dot);
                Column_builder.Append("trade_call = '" + txt_trade_call.Text.ToString() + "'" + str_dot);
                Column_builder.Append("trade_phone = '" + txt_trade_phone.Text.ToString() + "'" + str_dot);
                Column_builder.Append("trade_admin = '" + txt_trade_admin.Text.ToString() + "'" + str_dot);
                Column_builder.Append("trade_number = '" + txt_trade_number.Text.ToString() + "'" + str_dot);
                Column_builder.Append("trade_fax = '" + txt_trade_fax.Text.ToString() + "'" + str_dot);
                Column_builder.Append("trade_comment = '" + txt_comment.Text.ToString() + "'" + str_dot);
                Column_builder.Append("trade_location_id = '" + loc_selected_type.ToString() + "'");
                
            }

            string update_query = "update trade_info set " +
                Column_builder.ToString() +
                "where trade_info.id = " + get_trade_id;

            Console.WriteLine(update_query);

            try
            {
                Func_MySQL.instance.SetDATA(update_query).ExecuteNonQuery();

                MessageBox.Show("수정이 완료되었습니다");

            }
            catch(Exception ex)
            {

                Console.WriteLine(ex.ToString());

            }

            this.Close();

        }

        //저장
        private void btn_save_click(object sender, RoutedEventArgs e)
        {
            edit_save();
        }


        //닫기
        private void btn_close_click(object sender, RoutedEventArgs e)
        {
            this.Close();

        }
    }
}
