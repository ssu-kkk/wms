﻿using Prj_WMS.Controls;
using Prj_WMS.Functions;
using Prj_WMS.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prj_WMS.Screens_Sub
{
    /// <summary>
    /// W_Trade_Search.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class W_Trade_Search : Window
    {

        uC_SearchOption uC_txt_search_trade_code;
        uC_SearchOption uC_txt_search_trade_name;

        List<DataGridColumnNames> List_DataGridColumnNames = new List<DataGridColumnNames>();

        string MainSQL = "";



        public W_Trade_Search()
        {
            InitializeComponent();

            setSearchOptions();
            setGridColumns();

            MainSQL = "select trade_name, "
            + "trade_addr, "
            + "trade_call"
            + " from trade_info";

            setGridRows(GetMainSQL());



        }


        string GetMainSQL()
        {


            string MainSQL = "select id, " +
                "trade_name, "
               + "trade_addr, "
               + "trade_call"
               + " from trade_info";

            return MainSQL;

        }

        public uC_Control_Normarl_table MainTableControl;

        void setGridRows(string str_sql)
        {


            DataTable DT_TMP = Func_MySQL.instance.GetDATA(str_sql);



            DataTableItem _DataTableItem = new DataTableItem(List_DataGridColumnNames, str_sql, 5);
            GridData.Children.Clear();
            MainTableControl = new uC_Control_Normarl_table(_DataTableItem);
            MainTableControl.MouseDoubleClick += DataGridCell_MouseDoubleClick;
            GridData.Children.Add(MainTableControl);
        }



        private void DataGridCell_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            btn_use_Click(null, null);



        }

        public string selected_trade_id = "";
        public string selected_trade_name = "";
        public string selected_trade_call = "";
        //public string selected_staff_id = "";
        public bool getGridSelectedIndex()
        {
            if (MainTableControl.DG_1.SelectedItems.Count == 0)
            {
                MessageBox.Show("행을 선택해주세요");
                return false;
            }
            DataRowView row = (DataRowView)MainTableControl.DG_1.SelectedItems[0];


            selected_trade_id = row["id"].ToString();
            selected_trade_name = row["trade_name"].ToString();
            selected_trade_call = row["trade_call"].ToString();
            return true;

        }


        void setGridColumns()
        {


            List_DataGridColumnNames.Add(new DataGridColumnNames("id", false, 100));
            List_DataGridColumnNames.Add(new DataGridColumnNames("거래처이름", true, 100));
            List_DataGridColumnNames.Add(new DataGridColumnNames("연락처", true, 100));

        }

        void setSearchOptions()
        {

            List<String> ComboboxItems = new List<String>();


            string get_trade_type_sql = "select * from trade_info_type";
            DataTable DT_trade_types = Func_MySQL.instance.GetDATA(get_trade_type_sql);

            //for (int i = 0; i < DT_trade_types.Rows.Count; i++)
            //{
            //    string str_type_name = DT_trade_types.Rows[i]["type_name"].ToString();
            //    ComboboxItems.Add(str_type_name);
            //}



            SearchOptions SearchOptions_1 = new SearchOptions("거래처이름", Visibility.Hidden, true);
            uC_txt_search_trade_code = new uC_SearchOption(SearchOptions_1);
            uC_txt_search_trade_code.txt_search.KeyDown += OnKeyDownHandler;
            WrapPanel_search.Children.Add(uC_txt_search_trade_code);

            SearchOptions SearchOptions_2 = new SearchOptions("거래처연락처", Visibility.Hidden, true);
            uC_txt_search_trade_name = new uC_SearchOption(SearchOptions_2);
            uC_txt_search_trade_name.txt_search.KeyDown += OnKeyDownHandler;
            WrapPanel_search.Children.Add(uC_txt_search_trade_name);


        }

        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                Search_btn_Click(null, null);
            }
        }

        //초기화 
        private void btn_search_control_init_Click(object sender, RoutedEventArgs e)
        {

        }


        //전체보기 
        private void btn_search_all_Click(object sender, RoutedEventArgs e)
        {

        }


        //검색
        private void Search_btn_Click(object sender, RoutedEventArgs e)
        {

        }

        //거래처 입력 
        private void btn_use_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
