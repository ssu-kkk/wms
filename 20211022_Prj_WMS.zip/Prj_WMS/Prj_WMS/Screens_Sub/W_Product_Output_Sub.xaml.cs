﻿using Prj_WMS.Models;
using Prj_WMS.ViewModel;
using Prj_WMS.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using Prj_WMS.Screens;

namespace Prj_WMS.Screens_Sub
{
    /// <summary>
    /// W_Product_Output_Sub.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class W_Product_Output_Sub : Window
    {

        List<DataGridColumnNames> List_DataGridColumnNames = new List<DataGridColumnNames>();


        string MainSQL = "";


        string get_product_id = "";


        //전역
        string id;

        //trade_id 
        string trade_id;
        //type_id
        string type_id;


        string product_type_name;

        string product_code;
        string product_name;
        string product_trade_name;
        string product_now_count;
        string product_comment;



        //소켓 
        Socket client_socket; //소켓 선언
        bool isConnected; // bool로 서버와 클라이언트가 연결되었는지 판단 
        byte[] bytes = new byte[1024];
        string data; // 글자 데이터를 읽고 불러오는대 선언

        const char STX = (char)0x02; // stx
        const char ETX = (char)0x03; // etx


        public W_Product_Output_Sub(string get_product_id = "")
        {


            InitializeComponent();

            this.get_product_id = get_product_id;

            ControlSET(get_product_id);


 //           MainSQL = "select product_info.id,product_type_name, " +
 //"product_code, " +
 //"product_name, " +
 //"trade_name, " +
 //"product_now_count, " +
 //"product_comment " +
 //"from product_info " +
 //"left outer join product_info_type on product_type = product_info_type.id " +
 //"left outer join trade_info on product_trade_id = trade_info.id where product_info.id = " + get_product_id;



        }

        Model_Product _output_product_info;
        void ControlSET(string prod_id)
        {

            string get_data_sql = "select product_info.id, product_type, product_trade_id, " +
                "product_info_type.product_type_name, " +
"product_code, " +
"product_name, " +
"trade_name, " +
"product_now_count, " +
"product_comment " +
"from product_info " +
"left outer join product_info_type on product_type = product_info_type.id " +
"left outer join trade_info on product_trade_id = trade_info.id where product_info.id = " + prod_id;

 //           string get_data_sql = "select product_info.id,product_type_name, " +
 //"product_code, " +
 //"product_name, " +
 //"trade_name, " +
 //"product_now_count, " +
 //"product_comment " +
 //"from product_info " +
 //"left outer join product_info_type on product_type = product_info_type.id " +
 //"left outer join trade_info on product_trade_id = trade_info.id where product_info.id = " + prod_id;


            DataTable DT = Func_MySQL.instance.GetDATA(get_data_sql);

            if (DT.Rows.Count != 0)
            {
                id = DT.Rows[0]["id"].ToString();
                //string product_type = DT.Rows[0]["product_type"].ToString();
                type_id = DT.Rows[0]["product_type"].ToString();
                trade_id = DT.Rows[0]["product_trade_id"].ToString();
                product_type_name = DT.Rows[0]["product_type_name"].ToString();
                product_code = DT.Rows[0]["product_code"].ToString();
                product_name = DT.Rows[0]["product_name"].ToString();
                product_trade_name = DT.Rows[0]["trade_name"].ToString();
                product_now_count = DT.Rows[0]["product_now_count"].ToString();
                product_comment = DT.Rows[0]["product_comment"].ToString();


                //텍스트박스 채워줌 
                txt_prodduct_type.Text = product_type_name;
                txt_product_code.Text = product_code;
                txt_product_name.Text = product_name;
                txt_trade_name.Text = product_trade_name;
                txt_product_now_count.Text = product_now_count;

                txt_prodduct_type.IsReadOnly = true;
                txt_product_code.IsReadOnly = true;
                txt_product_name.IsReadOnly = true;
                txt_trade_name.IsReadOnly = true;
                txt_product_now_count.IsReadOnly = true;




            }

            else
            {
                MessageBox.Show("데이터베이스 오류 ");
            }


        }



        //numebrvalidationtext
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }


        //제품 출고하기 클릭 
        private void btn_product_output_save(object sender, RoutedEventArgs e)
        {
            output_save();
        }

        void output_save()
        {

            // insert문 필요
            string str_dot = ",";
            var Column_builder = new StringBuilder();
            var Value_builder = new StringBuilder();



            //str_dot << 
            string now_count = txt_product_now_count.Text;
            string minus_count = txt_product_output_count.Text;

            int i_now_count = Convert.ToInt32(now_count);

            int i_minus_count = Convert.ToInt32(minus_count);

            int update_count;



            if (i_now_count < i_minus_count)
            {
                MessageBox.Show("현재 수량보다 출고 수량이 더 많습니다. ");

                return;

            }
            else
            {
                //쿼리문 ㄱㄱ 

                if (Func_Util.YesOrNoMSGBOX("제품출고", txt_product_name.Text + "제품을 " + minus_count + "개 만큼 출고하시겠습니까"))
                {
                    //
                    //MessageBox.Show("dddd");

                    Column_builder.Append("id" + str_dot); Value_builder.Append("default" + str_dot);
                    Column_builder.Append("product_id" + str_dot); Value_builder.Append(id.ToString() + str_dot);
                    Column_builder.Append("type_id" + str_dot); Value_builder.Append(type_id.ToString() + str_dot);
                    Column_builder.Append("trade_id" + str_dot); Value_builder.Append(trade_id.ToString() + str_dot);
                    Column_builder.Append("product_output_count" + str_dot); Value_builder.Append(minus_count + str_dot);
                    Column_builder.Append("product_output_datetime" + str_dot); Value_builder.Append("now()" + str_dot);
                    Column_builder.Append("product_output_comment"); Value_builder.Append("'" + txt_comment.Text + "'");

                    string Output_Query = "insert into ms_product_info_output_log" +
                        "(" + Column_builder.ToString() + ") values" +
                        "(" + Value_builder.ToString() + ");";

                    //update << 
                    update_count = i_now_count - i_minus_count;
                    
                    string u_count_query = "update product_info set product_now_count = '" + update_count.ToString() + "' where id = " + get_product_id;


                    
                    Func_MySQL.instance.SetDATA(Output_Query).ExecuteNonQuery();

                    MessageBox.Show(minus_count.ToString() + "개만큼 출고가 완료되었습니다");

                    
                    Func_MySQL.instance.SetDATA(u_count_query).ExecuteNonQuery();


                    this.Close();

                    //connect();

                    //Func_Socket.instance.send_msg("B");
                    Func_Socket.instance.send_msg1("B");


                    //여기서 조져봄 
                    //try
                    //{
                    //    uC_Product_output.Instance.refreshMainTabControl();

                    //}
                    //catch (Exception ex)
                    //{
                    //    Console.WriteLine(ex.ToString());

                    //}


                }


                //여기서 count - < 

            }
        }


        //소켓 << 
        public void connect()
        {


            try
            {
                if (isConnected == true)
                    return;

                string tmp_ip = "192.168.0.77";
                string s_portNumber = "9090";

                int port_number = Convert.ToInt32(s_portNumber.Replace(" ", ""));

                client_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                client_socket.Connect(new IPEndPoint(IPAddress.Parse(tmp_ip), port_number));
                MessageBox.Show("소켓 연결");
                isConnected = true;
                Thread listen_thread = new Thread(do_receive);
                listen_thread.Start();

            }
            catch (Exception ex)
            {
                MessageBox.Show("통신을 위한 네트워크를 확인해주세요 ");

            }
        }

        public void send_msg(string signal)
        {
            if (isConnected == false)
                return;

            try
            {
                byte[] msg = Encoding.UTF8.GetBytes(signal);
                int byteSent = client_socket.Send(msg);

                signal = "";

            }
            catch(Exception ex)
            {
                MessageBox.Show("통신프로토콜 오류 ");

            }
        }

        void do_receive()
        {
            while (isConnected)
            {
                while (true)
                {
                    byte[] bytes = new byte[7];
                    int bytesRec = client_socket.Receive(bytes);

                    byte stx_tmp = Convert.ToByte(STX);
                    byte etx_tmp = Convert.ToByte(ETX);

                    if (bytes[0].Equals(stx_tmp))
                    {
                        byte[] cul_bytes = new byte[4];

                        for (int i = 0; i < cul_bytes.Length; i++)
                        {

                            cul_bytes[i] = bytes[i + 1];


                        }

                        data += Encoding.UTF8.GetString(cul_bytes, 0, cul_bytes.Length);

                    }
                    else
                    {

                        byte[] cul_bytes = new byte[4];
                        for (int i = 0; i < cul_bytes.Length; i++)
                        {
                            cul_bytes[i] = bytes[i + 1];

                        }
                        data += Encoding.UTF8.GetString(cul_bytes, 0, cul_bytes.Length);

                    }
                    data = data.Substring(0, data.Length);
                    Console.WriteLine(data);

                    //Invoke((MethodInvoker)delegate
                    //{
                    //    listBox1.Items.Add(data);
                    //}
                    //);

                    data = "";
                }

            }
        }


        //창닫기
        private void btn_close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();

        }
    }
}
