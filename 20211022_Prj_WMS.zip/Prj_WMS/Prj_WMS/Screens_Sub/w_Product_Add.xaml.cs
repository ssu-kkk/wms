﻿using Prj_WMS.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prj_WMS.Screens_Sub
{
    /// <summary>
    /// w_Product_Add.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class w_Product_Add : Window
    {
        public w_Product_Add()
        {
            InitializeComponent();

            txt_product_now_count.Text = "0";
            txt_product_now_count.IsReadOnly = true;


            //거래처 불러오기로 진행해서 잠금 
            txt_trade_name.IsReadOnly = true;

            SET_CMB();


        }



        //자재 종류 << 맞춰줌 
        void SET_CMB()
        {
            try
            {
                string get_product_type_sql = "select product_type_name from product_info_type";
                DataTable DT_product_type = Func_MySQL.instance.GetDATA(get_product_type_sql);

                List<string> type_list = new List<string>();

                for (int i = 0; i < DT_product_type.Rows.Count; i++)
                {
                    type_list.Add(DT_product_type.Rows[i]["product_type_name"].ToString());
                }
                cmb_type.ItemsSource = type_list;
                cmb_type.SelectedIndex = 0;



            }
            catch (Exception ex)
            {

            }
        }


        //numebrvalidationtext
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }



        private void btn_save_click(object sender, RoutedEventArgs e)
        {
            SaveData();

        }

        void SaveData()
        {

            string str_dot = ",";
            var Colmun_builder = new StringBuilder();
            var Value_builder = new StringBuilder();

            int selected_type = cmb_type.SelectedIndex + 1;
            //string s_selected_type = cmb_type.SelectedItem.ToString();

            

            //string 트레이드네임 ㄱㄱ 

            Colmun_builder.Append("id" + str_dot); Value_builder.Append("default" + str_dot);
            Colmun_builder.Append("product_type" + str_dot); Value_builder.Append(selected_type.ToString() + str_dot);
            Colmun_builder.Append("product_code" + str_dot); Value_builder.Append("'" + txt_product_code.Text + "'" + str_dot);
            Colmun_builder.Append("product_name" + str_dot); Value_builder.Append("'" + txt_product_name.Text + "'" + str_dot);
            Colmun_builder.Append("product_trade_id" + str_dot); Value_builder.Append("'" + txt_trade_id.Text + "'" + str_dot);
            Colmun_builder.Append("product_now_count" + str_dot); Value_builder.Append(txt_product_now_count.Text + str_dot);
            Colmun_builder.Append("product_comment"); Value_builder.Append("'" + txt_comment.Text + "'");
            //Colmun_builder.Append("product_trade_name"); Value_builder.Append("'" + txt_trade_name.Text + "'");
            //Colmun_builder.Append("product_info_type.product_type_name"); Value_builder.Append("'" + s_selected_type + "'");
            //Colmun_builder.Append("product_trade_name"); Value_builder.Append(txt_trade_id.Text == "" ? "0" : txt_trade_id.Text);


            var Log_Column_builder = new StringBuilder();
            var Log_Value_builder = new StringBuilder();

            Log_Column_builder.Append("id" + str_dot); Log_Value_builder.Append("default" + str_dot);
            // product_id
            Log_Column_builder.Append("product_id" + str_dot); Log_Value_builder.Append("default" + str_dot);
            //product_input_datetime
            Log_Column_builder.Append("product_input_datetime" + str_dot); Log_Value_builder.Append("'" + "now()" +  "'" + str_dot);
            //input메모 
            Log_Column_builder.Append("product_input_comment" + str_dot); Log_Value_builder.Append("'" + txt_comment.Text + "'" + str_dot);
            //input count 
            Log_Column_builder.Append("product_intput_count" ); Log_Value_builder.Append("'" + txt_product_now_count.Text + "'" );


            string Worklist_SAVE_SQL = "insert into product_info " +
         "(" + Colmun_builder.ToString() + ") values" +
         "(" + Value_builder.ToString() + ");";


            //string product_info_input_log = "insert into product_info_input_log" +
            //    "(" + Log_Column_builder.ToString() + ") values" + 
            //    "(" + Log_Value_builder.ToString() + ");";

            //데이터전송
            Func_MySQL.instance.SetDATA(Worklist_SAVE_SQL).ExecuteNonQuery();

            //input_log 한번 떄려봄 ㄲ 
           // Func_MySQL.instance.SetDATA(product_info_input_log).ExecuteNonQuery();

            MessageBox.Show("저장되었습니다");

            this.Close();

        }

        private void btn_close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();

        }


        W_Trade_Search _w_Trade_Search = new W_Trade_Search();
        private void btn_trade_search_click(object sender, RoutedEventArgs e)
        {
            _w_Trade_Search = new W_Trade_Search();
            _w_Trade_Search.btn_use.Click += window_trade_btn_use_click;
            _w_Trade_Search.MainTableControl.MouseDoubleClick += window_trade_btn_use_click;

            _w_Trade_Search.ShowDialog();



        }

        private void window_trade_btn_use_click(object sender, RoutedEventArgs e)
        {
            if (_w_Trade_Search.getGridSelectedIndex())
            {

                string trade_id = _w_Trade_Search.selected_trade_id;
                string trade_name = _w_Trade_Search.selected_trade_name;

                txt_trade_id.Text = trade_id;
                txt_trade_name.Text = trade_name;

                _w_Trade_Search.Close();




            }

            else
            {
                return;

            }
        }
    }
}
