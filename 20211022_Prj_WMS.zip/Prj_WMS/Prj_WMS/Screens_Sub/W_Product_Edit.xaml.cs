﻿using System;
using System.Collections.Generic;
using Prj_WMS.Functions;
using Prj_WMS.Models;
using Prj_WMS.ViewModel;

using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Text.RegularExpressions;

namespace Prj_WMS.Screens_Sub
{
    /// <summary>
    /// W_Product_Edit.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class W_Product_Edit : Window
    {


        string get_product_id = "";


        //전역
        string id;

        //trade_id 
        string trade_id;
        //type_id
        string type_id;


        string product_type_name;

        string product_code;
        string product_name;
        string product_trade_name;
        string product_now_count;
        string product_comment;




        public W_Product_Edit(string get_product_id = "")
        {
            InitializeComponent();

            this.get_product_id = get_product_id;

            SET_CMB();


            ControlSET(get_product_id);

        }



        //자재 종류 << 맞춰줌 
        void SET_CMB()
        {
            try
            {
                string get_product_type_sql = "select product_type_name from product_info_type";
                DataTable DT_product_type = Func_MySQL.instance.GetDATA(get_product_type_sql);

                List<string> type_list = new List<string>();

                for (int i = 0; i < DT_product_type.Rows.Count; i++)
                {
                    type_list.Add(DT_product_type.Rows[i]["product_type_name"].ToString());
                }
                cmb_type.ItemsSource = type_list;
                cmb_type.SelectedIndex = 0;



            }
            catch (Exception ex)
            {

            }
        }


        void ControlSET(string prod_id)
        {

//            string get_data_sql = "select product_info.id, product_type, " +
//               "product_info_type.product_type_name, " +
//"product_code, " +
//"product_name, " +
//"trade_name, " +
//"product_now_count, " +
//"product_comment " +
//"from product_info " +
//"left outer join product_info_type on product_type = product_info_type.id " +
//"left outer join trade_info on product_trade_id = trade_info.id where product_info.id = " + prod_id;

            //거래처 아이디 추가 버전 
            string get_data_sql = "select product_info.id, product_type, " +
              "product_info_type.product_type_name, " +
"product_code, " +
"product_name, " +
"product_trade_id, " +
"trade_name, " +
"product_now_count, " +
"product_comment " +
"from product_info " +
"left outer join product_info_type on product_type = product_info_type.id " +
"left outer join trade_info on product_trade_id = trade_info.id where product_info.id = " + prod_id;

            DataTable DT = Func_MySQL.instance.GetDATA(get_data_sql);

            if (DT.Rows.Count != 0)
            {
                
                id = DT.Rows[0]["id"].ToString();
                //string product_type = DT.Rows[0]["product_type"].ToString();
                type_id = DT.Rows[0]["product_type"].ToString();
                trade_id = DT.Rows[0]["product_trade_id"].ToString();
                product_type_name = DT.Rows[0]["product_type_name"].ToString();
                product_code = DT.Rows[0]["product_code"].ToString();
                product_name = DT.Rows[0]["product_name"].ToString();
                product_trade_name = DT.Rows[0]["trade_name"].ToString();
                product_now_count = DT.Rows[0]["product_now_count"].ToString();
                product_comment = DT.Rows[0]["product_comment"].ToString();


                //텍스트박스 채워줌 
                //txt_prodduct_type.Text = product_type_name;
                cmb_type.SelectedItem = product_type_name;

                txt_product_code.Text = product_code;
                txt_product_name.Text = product_name;
                txt_trade_name.Text = product_trade_name;
                txt_product_now_count.Text = product_now_count;
                txt_comment.Text = product_comment;

                // 추가 
                txt_trade_id.Text = trade_id;



            }

            else
            {
                MessageBox.Show("데이터베이스 오류 ");
            }


        }


        //numebrvalidationtext
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void btn_close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();


        }

        //수정하기 
        private void btn_product_edit_save(object sender, RoutedEventArgs e)
        {
            //edit_save();

        }

        void edit_save()
        {

            var str_dot = ", ";

            var Column_builder = new StringBuilder();
            var Value_builder = new StringBuilder();


            int selected_type = cmb_type.SelectedIndex + 1;



            if (Func_Util.YesOrNoMSGBOX("제품 수정", "제품을 수정하시겠습니까?"))
            {

                Column_builder.Append("product_type = '" + selected_type.ToString() + "'" + str_dot); 
                Column_builder.Append("product_code = '" + txt_product_code.Text + "'" + str_dot);
                Column_builder.Append("product_name = '" + txt_product_name.Text + "'" + str_dot); 
                //이부분 << 
                Column_builder.Append("product_trade_id = '" + txt_trade_id.Text + "'" + str_dot); 

                Column_builder.Append("product_now_count = '" + txt_product_now_count.Text + "'" + str_dot); 
                Column_builder.Append("product_comment = '" + txt_comment.Text + "'" + " "); 
                

            }

            string update_query = "update product_info set " +
                Column_builder.ToString() +
                
                "where product_info.id = " + get_product_id;


            Console.WriteLine(update_query);
            try
            {
                Func_MySQL.instance.SetDATA(update_query).ExecuteNonQuery();

                MessageBox.Show("수정이 완료되었습니다");


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }


            this.Close();

        }


        //제품 수정 
        private void btn_save_click(object sender, RoutedEventArgs e)
        {
            edit_save();
        }


        //거래처 불러오기 
        W_Trade_Search _w_Trade_Search = new W_Trade_Search();
        private void btn_trade_search_click(object sender, RoutedEventArgs e)
        {

            _w_Trade_Search = new W_Trade_Search();
            _w_Trade_Search.btn_use.Click += window_trade_btn_use_click;
            _w_Trade_Search.MainTableControl.MouseDoubleClick += window_trade_btn_use_click;

            _w_Trade_Search.ShowDialog();


            
        }

        private void window_trade_btn_use_click(object sender, RoutedEventArgs e)
        {
            if (_w_Trade_Search.getGridSelectedIndex())
            {

                string trade_id = _w_Trade_Search.selected_trade_id;
                string trade_name = _w_Trade_Search.selected_trade_name;

                txt_trade_id.Text = trade_id;
                txt_trade_name.Text = trade_name;

                _w_Trade_Search.Close();




            }

            else
            {
                return;

            }
        }

    }
}
