﻿using Prj_WMS.ViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prj_WMS.Controls
{
    /// <summary>
    /// uC_DateTime.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class uC_DateTime : UserControl
    {
        public uC_DateTime(Control_Datetime_Items _Control_Datetime_Items)
        {
            InitializeComponent();
            this.DataContext = _Control_Datetime_Items;

        }

        private void ClearComboBox_Click(object sender, RoutedEventArgs e)
        {
            control_datetime.SelectedDate = null;
        }

        private void Today_Click(object sender, RoutedEventArgs e)
        {
            control_datetime.SelectedDate = DateTime.Today;
        }
    }
}
