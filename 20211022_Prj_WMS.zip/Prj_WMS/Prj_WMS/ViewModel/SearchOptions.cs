﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prj_WMS.ViewModel
{
    public class SearchOptions
    {
        public SearchOptions(string name, System.Windows.Visibility BtnVisible, bool ControlEnable)
        {
            Name = name;
            this.iMode = iMode;
            this.BtnVisible = BtnVisible;
            this.ControlEnable = ControlEnable;
        }

        public string Name { get; private set; }

        public int iMode { get; set; }
        public System.Windows.Visibility BtnVisible { get; set; }
        public bool ControlEnable { get; set; }

    }
}
