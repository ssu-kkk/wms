﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prj_WMS.ViewModel
{
    public class DataGridColumnNames
    {

        public DataGridColumnNames(string _ColumnName, bool _isVisible, int _ColumnSizeRate)
        {
            ColumnName = _ColumnName;
            isVisible = _isVisible;
            ColumnSizeRate = _ColumnSizeRate;
        }

        public string ColumnName { get; private set; }
        public bool isVisible { get; private set; }
        public int ColumnSizeRate { get; set; }

    }
}
