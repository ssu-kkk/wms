﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prj_WMS.ViewModel
{
    public class Control_Datetime_Items
    {
        public Control_Datetime_Items(string Name)
        {
            this.Name = Name;

        }

        public string Name { get; set; }
    }
}
