﻿using Prj_WMS.Functions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;

namespace Prj_WMS.ViewModel
{
    public class DataTableItem : INotifyPropertyChanged
    {
        //Func_MySQL _Func_MySQL = new Func_MySQL();

        public DataTableItem(List<DataGridColumnNames> _DataGridColumnNames, string str_sql, int iOne_page_size)
        {
            List_DataGridColumnNames = _DataGridColumnNames;
            this.str_sql = str_sql;
            this.iOne_page_size = iOne_page_size;
            i_now_page = 1;
            RefreshINFO(1, this.str_sql);

        }

        public void RefreshINFO(int i_now_page = 1, string str_sql = "")
        {
            try
            {


                if (tmp_str_sql != str_sql && !string.IsNullOrEmpty(str_sql))
                {
                    this.str_sql = str_sql;
                    i_now_page = 1;
                    tmp_now_page = i_now_page;
                }

                start_page_count = (int)(iOne_page_size * i_now_page) - iOne_page_size;
                end_page_count = iOne_page_size;
                str_iPage_size_sql = "select count(*) as iPage_size from(" + this.str_sql + ") as tmptable";
                string str_convert_sql = "select * from(" + this.str_sql + " limit " + start_page_count + "," + end_page_count + ") as tmptable";
                if (iOne_page_size == 0)
                {//미지정시 전체
                    str_convert_sql = this.str_sql;
                }
                if (!string.IsNullOrEmpty(str_sql) || tmp_now_page != i_now_page)
                {
                    DT = Func_MySQL.instance.GetDATA(str_convert_sql);
                    tmp_now_page = i_now_page;
                }
                this.iPage_all_Count = Convert.ToInt32(Func_MySQL.instance.GetDATA(str_iPage_size_sql).Rows[0]["iPage_size"].ToString());


                if (iPage_all_Count == 0)
                {
                    str_page_text = 0 + " - " + 0 + " of " + 0;
                    str_page_num_text = " / " + 0;
                    return;
                }

                double dPage_Count = 0;
                if ((double)iOne_page_size == 0)
                {
                    dPage_Count = 1;
                }
                else

                {
                    dPage_Count = (double)this.iPage_all_Count / (double)iOne_page_size;
                }


                iPage_Count = Convert.ToInt32(Math.Ceiling(dPage_Count));


                if (end_page_count > this.iPage_all_Count)
                {
                    end_page_count = this.iPage_all_Count;
                }



                end_page_count = (int)(iOne_page_size * i_now_page);
                if (end_page_count > iPage_all_Count)
                {
                    int iLackNumber = end_page_count - iPage_all_Count;

                    end_page_count = iPage_all_Count;


                    for (int i = 0; i < DT.Columns.Count; i++)
                    {
                        DT.Columns[i].AllowDBNull = true;
                    }

                    for (int i = 0; i < iLackNumber; i++)
                    {
                        DataRow row = DT.NewRow();
                        DT.Rows.Add(row);
                    }

                }
                int tmp_start_page_count = start_page_count + 1;
                str_page_text = tmp_start_page_count + " - " + end_page_count + " of " + iPage_all_Count;
                str_page_num_text = " / " + iPage_Count;



            }
            catch (Exception ex)
            {

            }

        }
        string tmp_str_sql { get; set; }
        int tmp_now_page = 0;

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }


        private DataTable _DT;
        private string _str_page_text;
        private string _str_page_num_text;
        private int _i_now_page;


        public List<DataGridColumnNames> List_DataGridColumnNames { get; set; }
        public string str_sql { get; set; }
        public DataTable DT
        {
            get
            {
                return _DT;
            }
            set
            {
                _DT = value;
                OnPropertyChanged("DT");
            }
        }


        public int iPage_all_Count { get; private set; } // 전체개수
        public int iPage_Count { get; set; } // 페이지 개수
        public int iOne_page_size { get; set; }// 한 페이지에 표시할 개수
        public string str_iPage_size_sql { get; private set; } // 전체개수 가져올 sql
        public int start_page_count { get; private set; }
        public int end_page_count { get; private set; }
        public string str_page_text
        {
            get
            {
                return _str_page_text;
            }
            set
            {
                this._str_page_text = value;
                OnPropertyChanged("str_page_text");
            }
        }
        public string str_page_num_text
        {
            get
            {
                return _str_page_num_text;
            }
            set
            {
                this._str_page_num_text = value;
                OnPropertyChanged("str_page_num_text");
            }
        }
        public int i_now_page
        {
            get
            {
                return _i_now_page;
            }
            set
            {
                this._i_now_page = value;

            }
        }



    }
}
