﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;
using System.ComponentModel;


namespace Prj_WMS.ViewModel
{
    public class Drgablz_Main_TabItem : INotifyPropertyChanged
    {
        public Drgablz_Main_TabItem(string _Header_TEXT, UserControl _Main_Binding_Item)
        {
            MyTab = new TabItem { Header = _Header_TEXT, Content = _Main_Binding_Item };
            Header_TEXT = _Header_TEXT;


        }
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        private TabItem _MyTab;
        private string _Header_TEXT { get; set; }

        public string Header_TEXT
        {
            get
            {
                return _Header_TEXT;
            }
            set
            {
                this._Header_TEXT = value;
                OnPropertyChanged("Header_TEXT");
            }
        }

        public TabItem MyTab
        {
            get
            {
                return _MyTab;
            }
            set
            {
                this._MyTab = value;
                OnPropertyChanged("MyTab");
            }
        }

        public UserControl _Main_Binding_Item { get; set; }


    }
}
