﻿using Prj_WMS.Controls;
using Prj_WMS.Functions;
using Prj_WMS.Screens_Sub;
using Prj_WMS.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prj_WMS.Screens
{
    /// <summary>
    /// uC_Product_Info.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class uC_Product_Info : UserControl
    {

        uC_SearchOption uC_txt_search_product_tradename;
        uC_SearchOption uC_txt_search_product_name;

        static string MainSQL = "";

        // 제품추가
        w_Product_Add _w_Product_Add;

        //제품수정 
        W_Product_Edit _w_Product_edit;


        //싱글톤 
        static uC_Product_Info _instance;



        //싱글톤
        public static uC_Product_Info Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new uC_Product_Info();
                }
                return _instance;

            }
        }


        public uC_Product_Info()
        {
            InitializeComponent();

            setSearchOptions();

            setGridColumns();

            MainSQL = "select product_info.id, product_type, " +
                "product_info_type.product_type_name, " +
"product_code, " +
"product_name, " +
"trade_name, " +
"product_now_count, " +
"product_comment " + 
"from product_info " +
"left outer join product_info_type on product_type = product_info_type.id " +
"left outer join trade_info on product_trade_id = trade_info.id ";

            setGridRows(MainSQL);

            _instance = this;

        }


        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                btn_Search_Product_Click(null, null);
            }
        }


        List<DataGridColumnNames> List_DataGridColumnNames = new List<DataGridColumnNames>();


        void setSearchOptions()
        {


            // 품명 
            SearchOptions SearchOptions_2 = new SearchOptions("품명", Visibility.Collapsed, true);
            uC_txt_search_product_name = new uC_SearchOption(SearchOptions_2);
            uC_txt_search_product_name.txt_search.KeyDown += OnKeyDownHandler;
            WrapPanel_search.Children.Add(uC_txt_search_product_name);


            SearchOptions SearchOptions_1 = new SearchOptions("거래처", Visibility.Collapsed, true);
            uC_txt_search_product_tradename = new uC_SearchOption(SearchOptions_1);
            uC_txt_search_product_tradename.txt_search.KeyDown += OnKeyDownHandler;
            WrapPanel_search.Children.Add(uC_txt_search_product_tradename);



        }

        string GetSearchSQL()
        {
            string where_sql = "";
            // int trade_type = uC_Combobox_search_type.control_cmb.SelectedIndex + 1;




            //거래처 
            string acc_id = uC_txt_search_product_tradename.txt_search.Text;
            where_sql += Func_MySQL.instance.GetWhereSQL(1, "trade_name", acc_id, "like", "and");


            //품명
            string acc_staff_name = uC_txt_search_product_name.txt_search.Text;
            //where_sql += Func_MySQL.instance.GetWhereSQL(1, "(select staff_name from staff_info where id = account_staff_id)", acc_staff_name, "like", "and");
            where_sql += Func_MySQL.instance.GetWhereSQL(1, "product_name", acc_staff_name, "like", "and");

            if (!string.IsNullOrEmpty(where_sql))
            {
                where_sql = " where " + where_sql + " product_info.id is not null";
            }



            return where_sql;
        }

        void setGridColumns()
        {


            //  List<DataGridColumnNames> List_DataGridColumnNames = new List<DataGridColumnNames>();
            List_DataGridColumnNames.Add(new DataGridColumnNames("ID", false, 100));
            List_DataGridColumnNames.Add(new DataGridColumnNames("구분ID", false, 0));

            List_DataGridColumnNames.Add(new DataGridColumnNames("구분", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("품번", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("품명", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("거래처", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("재고", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("메모", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("거래처", true, 0));

            // List_DataGridColumnNames.Add(new DataGridColumnNames("사용인원", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("거래처명", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("연락처", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("팩스", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("주소", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("이메일", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("홈페이지", true, 0));

        }
        uC_Control_Normarl_table MainTableControl;


        //쿼리문 파라미터로 받아 DataTable에 저장 후 그리드뷰로 전달 
        void setGridRows(string str_sql)
        {


            //  DataTable DT_TMP = Func_MySQL.instance.GetDATA(str_sql);

            DataTableItem _DataTableItem = new DataTableItem(List_DataGridColumnNames, str_sql, 18);
            GridData.Children.Clear();
            MainTableControl = new uC_Control_Normarl_table(_DataTableItem);
            GridData.Children.Add(MainTableControl);
        }



        //제품 로우값 id 긁어오는 메소드 
        string getGridSelectedIndex()
        {

            if ((DataRowView)MainTableControl.DG_1.SelectedItem == null)
            {
                //MessageBox.Show("행을 선택해주세요");
                return "";
            }

            if ((DataRowView)MainTableControl.DG_1.SelectedItems[0] == null)
            {
                MessageBox.Show("행을 선택해주세요");
                return "";
            }

            DataRowView row = (DataRowView)MainTableControl.DG_1.SelectedItems[0];


            string trade_info_id = row["id"].ToString();

            return trade_info_id;
        }

        //제품 삭제 
        private void btn_Product_del_Click(object sender, RoutedEventArgs e)
        {
            string product_info_id = getGridSelectedIndex();
            if (product_info_id.Length == 0)
            {
                MessageBox.Show("행을 선택해주세요");
                return;

            }

            else
            {
                if (Func_Util.YesOrNoMSGBOX("삭제", "삭제하시겠습니까?"))
                {

                    string del_sql = "delete from product_info where id = " + product_info_id;
                    Func_MySQL.instance.SetDATA(del_sql).ExecuteNonQuery();

                    MainTableControl.refreshThisPages();

                }
            }

         
        }


        //제품 수정 
        private void btn_Product_Edit_Click(object sender, RoutedEventArgs e)
        {
            if(GridEditData.Children.Count > 0)
            {
                GridEditData.Children.Clear();

            }

            else
            {

                string temp_Sql = "";

                // product_info_id  << ㅇㅇ 
                string product_info_id = getGridSelectedIndex();

                if(product_info_id.Length == 0)
                {
                    MessageBox.Show("행을 선택해주세요");
                    return;

                }

                else
                {


                    W_Product_Edit _w_Product_edit = new W_Product_Edit(product_info_id);

                    _w_Product_edit.ShowDialog();

                    MainTableControl.Refresh_pages(1, MainSQL);

                }




                //GridEditData.Children.Add(new uC_Staff_Sub(this, prod_id));

                //GridEditData.Children.Add(new uC_Product_Sub_Add());
            }
        }

        //제품 추가 
        private void btn_Product_Add_Click(object sender, RoutedEventArgs e)
        {
            _w_Product_Add = new w_Product_Add();

            //_w_Product_Add.Show();
            _w_Product_Add.ShowDialog();


            MainTableControl.Refresh_pages(1, MainSQL);


        }


        //초기화 클릭
        private void btn_Search_Product_Init_Click(object sender, RoutedEventArgs e)
        {
            uC_txt_search_product_name.txt_search.Text = "";
            uC_txt_search_product_tradename.txt_search.Text = "";
        }


        //전체보기 
        private void btn_Search_Product_All_Click(object sender, RoutedEventArgs e)
        {
            MainTableControl.Refresh_pages(1, MainSQL);
        }


        //검색 클릭 
        private void btn_Search_Product_Click(object sender, RoutedEventArgs e)
        {
            string search_sql = MainSQL + GetSearchSQL();
            MainTableControl.Refresh_pages(1, search_sql);
        }


        //제품출고
        private void btn_Product_Output_Click(object sender, RoutedEventArgs e)
        {

            string product_info_id = getGridSelectedIndex();


            if(product_info_id.Length == 0)
            {
                MessageBox.Show("행을 선택해주세요");
                return;

            }

            W_Product_Output_Sub _output_sub = new W_Product_Output_Sub(product_info_id);

            _output_sub.ShowDialog();


            MainTableControl.Refresh_pages(1, MainSQL);

            Console.WriteLine("refresh");

            //uC_Product_output.instance._
            //아웃풋 탭컨트롤 리프레시
            try
            {
                //uC_Product_output.Instance.refreshMainTabControl();
                //uC_Product_output.instance.refreshMainTabControl();
                uC_Product_output.Instance.refreshMainTabControl();



            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }


        }


        // 제품 입고 
        private void btn_Product_input_Click(object sender, RoutedEventArgs e)
        {
            string product_info_id = getGridSelectedIndex();


            if (product_info_id.Length == 0)
            {
                MessageBox.Show("행을 선택해주세요");
                return;

            }

            W_Product_Input_Sub _input_sub = new W_Product_Input_Sub(product_info_id);

            _input_sub.ShowDialog();

            MainTableControl.Refresh_pages(1, MainSQL);

            try
            {
                uC_Prouduct_input.Instance.refreshMainTabControl();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }

        }


        //리프레시
        public void refreshMainTabControl()
        {
            MainTableControl.Refresh_pages(1, MainSQL);

        }
    }
}
