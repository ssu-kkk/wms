﻿using Prj_WMS.Controls;
using Prj_WMS.Functions;
using Prj_WMS.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prj_WMS.Screens
{
    /// <summary>
    /// uC_Prouduct_input.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class uC_Prouduct_input : UserControl
    {


        //싱글톤
        static uC_Prouduct_input _instance;



        // uc 검색옵션 
        uC_SearchOption uC_txt_search_input_name;
        uC_SearchOption uC_txt_search_input_trade_name;

        //메인 sql 
        static string MainSQL = "";



        //인서트문 필요 string 
        string product_id;
        string type_id;
        string trade_id;
        string product_info_input_log_id;
        string product_input_cancel_datetime;

        //총재고 조회해주는거 
        string now_count;
        string cancel_count;



        //싱글톤
        public static uC_Prouduct_input Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new uC_Prouduct_input();
                }
                return _instance;

            }
        }

        public uC_Prouduct_input()
        {
            InitializeComponent();


            setSearchOptions();

            setGridColumns();

            //product_info 꺼 sql 
            MainSQL = "select ms_product_info_input_log.id, product_info_type.product_type_name, " +
                "product_info.product_code, product_info.product_name, " +
                "trade_info.trade_name, " +
                "product_input_datetime, " +
                "product_input_count, " +
                "product_input_comment " +
                "from ms_product_info_input_log " +
"left outer join product_info on product_id = product_info.id " +
"left outer join product_info_type on type_id = product_info_type.id " +
"left outer join trade_info on trade_id = trade_info.id";

            setGridRows(MainSQL);

            _instance = this;

        }


        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                btn_Input_Search_Click(null, null);
            }
        }


        List<DataGridColumnNames> List_DataGridColumnNames = new List<DataGridColumnNames>();


        void setSearchOptions()
        {


            SearchOptions SearchOptions_1 = new SearchOptions("품명", Visibility.Collapsed, true);
            uC_txt_search_input_name = new uC_SearchOption(SearchOptions_1);
            uC_txt_search_input_name.txt_search.KeyDown += OnKeyDownHandler;
            WrapPanel_search.Children.Add(uC_txt_search_input_name);

            SearchOptions SearchOptions_2 = new SearchOptions("거래처", Visibility.Collapsed, true);
            uC_txt_search_input_trade_name = new uC_SearchOption(SearchOptions_2);
            uC_txt_search_input_trade_name.txt_search.KeyDown += OnKeyDownHandler;
            WrapPanel_search.Children.Add(uC_txt_search_input_trade_name);



        }

        string GetSearchSQL()
        {
            string where_sql = "";
            // int trade_type = uC_Combobox_search_type.control_cmb.SelectedIndex + 1;



            string product_name = uC_txt_search_input_name.txt_search.Text;
            where_sql += Func_MySQL.instance.GetWhereSQL(1, "product_name", product_name, "like", "and");

            string trade_name = uC_txt_search_input_trade_name.txt_search.Text;
            where_sql += Func_MySQL.instance.GetWhereSQL(1, "trade_name", trade_name, "like", "and");

            if (!string.IsNullOrEmpty(where_sql))
            {
                where_sql = " where " + where_sql + " product_info.id is not null";
            }



            return where_sql;
        }

        void setGridColumns()
        {


            //  List<DataGridColumnNames> List_DataGridColumnNames = new List<DataGridColumnNames>();



            List_DataGridColumnNames.Add(new DataGridColumnNames("ID", false, 100));
            List_DataGridColumnNames.Add(new DataGridColumnNames("구분", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("품번", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("품명", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("거래처", true, 0));

            List_DataGridColumnNames.Add(new DataGridColumnNames("출고날짜", true, 0));

            List_DataGridColumnNames.Add(new DataGridColumnNames("입고 수량", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("메모", true, 0));

            // List_DataGridColumnNames.Add(new DataGridColumnNames("사용인원", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("거래처명", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("연락처", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("팩스", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("주소", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("이메일", true, 0));
            //List_DataGridColumnNames.Add(new DataGridColumnNames("홈페이지", true, 0));

        }
        uC_Control_Normarl_table MainTableControl;


        void setGridRows(string str_sql)
        {


            //  DataTable DT_TMP = Func_MySQL.instance.GetDATA(str_sql);

            DataTableItem _DataTableItem = new DataTableItem(List_DataGridColumnNames, str_sql, 18);
            GridData.Children.Clear();
            MainTableControl = new uC_Control_Normarl_table(_DataTableItem);
            GridData.Children.Add(MainTableControl);
        }


        //제품 로우값 id 긁어오는 메소드 
        string getGridSelectedIndex()
        {

            if ((DataRowView)MainTableControl.DG_1.SelectedItem == null)
            {
                //MessageBox.Show("행을 선택해주세요");
                return "";
            }

            if ((DataRowView)MainTableControl.DG_1.SelectedItems[0] == null)
            {
                MessageBox.Show("행을 선택해주세요");
                return "";
            }

            DataRowView row = (DataRowView)MainTableControl.DG_1.SelectedItems[0];


            string trade_info_id = row["id"].ToString();

            return trade_info_id;
        }



        //입고 기록 삭제 
        private void btn_Product_Input_Del_Click(object sender, RoutedEventArgs e)
        {
            string product_info_id = getGridSelectedIndex();
            if (product_info_id == null)
            {
                MessageBox.Show("행을 선택해주세요");
                return;

            }

            if (Func_Util.YesOrNoMSGBOX("삭제", "삭제하시겠습니까?"))
            {

                //쿼리문 바꿔줘야함 20210804 
                string del_sql = "delete from ms_product_info_input_log where id = " + product_info_id;
                Func_MySQL.instance.SetDATA(del_sql).ExecuteNonQuery();

                MainTableControl.refreshThisPages();

            }
        }



        public void refreshMainTabControl()
        {
            //MainTableControl.refreshThisPages();

            MainTableControl.Refresh_pages(1, MainSQL);

        }



        //수정 클릭 
        private void btn_Product_Input_Edit_Click(object sender, RoutedEventArgs e)
        {

        }

        //private void btn_Data_add_Click(object sender, RoutedEventArgs e)
        //{

        //}


        //입고관리 추가 클릭 이벤트  
        private void btn_Product_Input_Add_Click(object sender, RoutedEventArgs e)
        {


        }


        //검색부분 초기화 
        private void btn_Input_Init_Click(object sender, RoutedEventArgs e)
        {
            uC_txt_search_input_name.txt_search.Text = "";
            uC_txt_search_input_trade_name.txt_search.Text = "";
        }

        //검색부분 전체보기 클릭 
        private void btn_Input_All_Click(object sender, RoutedEventArgs e)
        {
            MainTableControl.Refresh_pages(1, MainSQL);

        }


        public void Refresh_page()
        {
            MainTableControl.Refresh_pages(1, MainSQL);

        }


        //검색부분 검색하기 클릭 
        private void btn_Input_Search_Click(object sender, RoutedEventArgs e)
        {


            string search_sql = MainSQL + GetSearchSQL();
            MainTableControl.Refresh_pages(1, search_sql);

        }


        //입고 취소 
        private void btn_Product_Input_Cancel_Click(object sender, RoutedEventArgs e)
        {


            var str_dot = ",";

            var Column_builder = new StringBuilder();
            var Value_builder = new StringBuilder();


            string product_input_id = getGridSelectedIndex();

            if (product_input_id.Length == 0)
            {
                MessageBox.Show("행을 선택해주세요");
                return;
            }

            get_data(product_input_id);


            if (Func_Util.YesOrNoMSGBOX("입고취소", "입고를 취소하시겠습니까? "))
            {

                Column_builder.Append("id" + str_dot); Value_builder.Append("default" + str_dot);
                Column_builder.Append("product_id" + str_dot); Value_builder.Append(product_id + str_dot);
                Column_builder.Append("type_id" + str_dot); Value_builder.Append(type_id + str_dot);
                Column_builder.Append("trade_id" + str_dot); Value_builder.Append(trade_id + str_dot);
                Column_builder.Append("product_info_input_log_id" + str_dot); Value_builder.Append(product_info_input_log_id + str_dot);
                Column_builder.Append("product_input_cancel_datetime" + str_dot); Value_builder.Append("now()" + str_dot);
                Column_builder.Append("product_input_cancel_comment" + str_dot); Value_builder.Append("\"\"" + str_dot);
                Column_builder.Append("product_input_count_cancel"); Value_builder.Append(cancel_count);


                //cancel_count


                //string input_Query = "insert into ms_product_info_input_cancel_log" +
                //        "(" + Column_builder.ToString() + ") values" +
                //        "(" + Value_builder.ToString() + ");";


                //Func_MySQL.instance.SetDATA(input_Query).ExecuteNonQuery();

                int i_cancel_count = Convert.ToInt32(cancel_count);
                int i_now_count = Convert.ToInt32(now_count);

                // - 해줘야함 입고 취소니까 현재에서 마이너스 < 
                int i_edit_count = i_now_count - i_cancel_count;

                if (i_edit_count < 0)
                {
                    MessageBox.Show("현재 개수보다 취소해야하는 개수가 더 많습니다.");
                    return;

                }
                else
                {
                    string input_Query = "insert into ms_product_info_input_cancel_log" +
                    "(" + Column_builder.ToString() + ") values" +
                    "(" + Value_builder.ToString() + ");";


                    Func_MySQL.instance.SetDATA(input_Query).ExecuteNonQuery();


                    string edit_count = i_edit_count.ToString();

                    string edit_count_query = "update product_info set product_now_count = '" + edit_count + "' where id = " + product_id;

                    try
                    {



                        Func_MySQL.instance.SetDATA(edit_count_query).ExecuteNonQuery();


                        MessageBox.Show("입고취소 완료");

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("입고취소 오류 " + ex.ToString());

                    }


                    //쿼리문 바꿔줘야함 20210804 
                    string del_sql = "delete from ms_product_info_input_log where id = " + product_input_id;
                    Func_MySQL.instance.SetDATA(del_sql).ExecuteNonQuery();

                    MainTableControl.refreshThisPages();




                    //싱글톤 총개수 변화 product_info 
                    try
                    {
                        uC_Product_Info.Instance.refreshMainTabControl();

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }

                    //input_cancel_log 리프레시
                    try
                    {
                        uC_Product_Input_Cancel.Instance.refreshMainTabControl();

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());

                    }
                }

                


            }
        }


        void get_data(string prod_id)
        {


            string get_data_sql = "select ms_product_info_input_log.id, " +
                "product_id, " +
                "type_id, " +
                "trade_id, " +
                "product_input_count " +
                "from ms_product_info_input_log " +
                "left outer join product_info on product_id = product_info.id " +
                "left outer join product_info_type on type_id = product_info_type.id " +
                "left outer join trade_info on product_trade_id = trade_info.id where ms_product_info_input_log.id = " + prod_id;

            DataTable DT = Func_MySQL.instance.GetDATA(get_data_sql);

            if (DT.Rows.Count != 0)
            {


                //string product_id;
                //string type_id;
                //string trade_id;
                //string product_info_input_log_id;
                //string product_input_cancel_datetime;

                product_id = DT.Rows[0]["product_id"].ToString();
                type_id = DT.Rows[0]["type_id"].ToString();
                trade_id = DT.Rows[0]["trade_id"].ToString();
                product_info_input_log_id = DT.Rows[0]["id"].ToString();

                //인풋카운트
                cancel_count = DT.Rows[0]["product_input_count"].ToString();




                //id = DT.Rows[0]["id"].ToString();
                ////string product_type = DT.Rows[0]["product_type"].ToString();
                //type_id = DT.Rows[0]["product_type"].ToString();
                //trade_id = DT.Rows[0]["product_trade_id"].ToString();
                //product_type_name = DT.Rows[0]["product_type_name"].ToString();
                //product_code = DT.Rows[0]["product_code"].ToString();
                //product_name = DT.Rows[0]["product_name"].ToString();
                //product_trade_name = DT.Rows[0]["trade_name"].ToString();
                //product_now_count = DT.Rows[0]["product_now_count"].ToString();
                //product_comment = DT.Rows[0]["product_comment"].ToString();


            }

            string get_now_count_sql = "select product_now_count from product_info where id = " + product_id;

            DataTable DT1 = Func_MySQL.instance.GetDATA(get_now_count_sql);

            if (DT1.Rows.Count != 0)
            {
                now_count = DT1.Rows[0]["product_now_count"].ToString();

            }


            void input_cancel_save()
            {
                var str_dot = ",";

                var Column_builder = new StringBuilder();
                var Value_builder = new StringBuilder();



            }
        }
    }

}
