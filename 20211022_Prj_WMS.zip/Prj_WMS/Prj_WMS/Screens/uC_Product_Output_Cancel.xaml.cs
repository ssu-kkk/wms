﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Prj_WMS.Controls;
using Prj_WMS.Functions;
using Prj_WMS.ViewModel;



namespace Prj_WMS.Screens
{
    /// <summary>
    /// uC_Product_Output_Cancel.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class uC_Product_Output_Cancel : UserControl
    {


        static uC_Product_Output_Cancel _instance;


        // uc 검색옵션 
        uC_SearchOption uC_txt_search_output_name;
        uC_SearchOption uC_txt_search_output_trade_name;


        static string MainSQL = "";


        //싱글톤 
        public static uC_Product_Output_Cancel Instance
        {
            get
            {
                if (_instance == null) _instance = new uC_Product_Output_Cancel();
                return _instance;

            }
        }



        public uC_Product_Output_Cancel()
        {
            InitializeComponent();

            setSearchOptions();
            setGridColumns();


            //product_info 꺼 sql 
            MainSQL = "select ms_product_info_output_cancel_log.id, product_info_type.product_type_name, " +
                "product_info.product_code, " +
                "product_info.product_name, " +
                "trade_info.trade_name, " +
               // "ms_product_info_output_log.product_output_count, " +
                "product_output_count_cancel, " + 
                "product_output_cancel_datetime " +
                "from ms_product_info_output_cancel_log " +
"left outer join product_info on product_id = product_info.id " +
"left outer join product_info_type on type_id = product_info_type.id " +
"left outer join trade_info on trade_id = trade_info.id " +
"left outer join ms_product_info_output_log on product_info_output_log_id = ms_product_info_output_log.id";

            setGridRows(MainSQL);

            _instance = this;


        }

        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                btn_Search_Product_Click(null, null);
            }
        }


        List<DataGridColumnNames> List_DataGridColumnNames = new List<DataGridColumnNames>();


        void setSearchOptions()
        {


            SearchOptions SearchOptions_1 = new SearchOptions("품명", Visibility.Collapsed, true);
            uC_txt_search_output_name = new uC_SearchOption(SearchOptions_1);
            uC_txt_search_output_name.txt_search.KeyDown += OnKeyDownHandler;
            WrapPanel_search.Children.Add(uC_txt_search_output_name);

            SearchOptions SearchOptions_2 = new SearchOptions("거래처", Visibility.Collapsed, true);
            uC_txt_search_output_trade_name = new uC_SearchOption(SearchOptions_2);
            uC_txt_search_output_trade_name.txt_search.KeyDown += OnKeyDownHandler;
            WrapPanel_search.Children.Add(uC_txt_search_output_trade_name);


        }

        void setGridColumns()
        {




            List_DataGridColumnNames.Add(new DataGridColumnNames("ID", false, 100));
            List_DataGridColumnNames.Add(new DataGridColumnNames("구분", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("품번", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("품명", true, 0));
            List_DataGridColumnNames.Add(new DataGridColumnNames("거래처", true, 0));

            List_DataGridColumnNames.Add(new DataGridColumnNames("출고취소수량", true, 0));

            List_DataGridColumnNames.Add(new DataGridColumnNames("출고취소날짜", true, 0));

         
            List_DataGridColumnNames.Add(new DataGridColumnNames("메모", true, 0));

        }
        uC_Control_Normarl_table MainTableControl;


        void setGridRows(string str_sql)
        {


            //  DataTable DT_TMP = Func_MySQL.instance.GetDATA(str_sql);

            DataTableItem _DataTableItem = new DataTableItem(List_DataGridColumnNames, str_sql, 18);
            GridData.Children.Clear();
            MainTableControl = new uC_Control_Normarl_table(_DataTableItem);
            GridData.Children.Add(MainTableControl);
        }


        string GetSearchSQL()
        {
            string where_sql = "";
            // int trade_type = uC_Combobox_search_type.control_cmb.SelectedIndex + 1;



            string output_name = uC_txt_search_output_name.txt_search.Text;
            where_sql += Func_MySQL.instance.GetWhereSQL(1, "product_name", output_name, "like", "and");

            string trade_name = uC_txt_search_output_trade_name.txt_search.Text;
            where_sql += Func_MySQL.instance.GetWhereSQL(1, "trade_name", trade_name, "like", "and");

            if (!string.IsNullOrEmpty(where_sql))
            {
                where_sql = " where " + where_sql + " product_info.id is not null";
            }



            return where_sql;
        }



        //제품 로우값 id 긁어오는 메소드 
        string getGridSelectedIndex()
        {

            if ((DataRowView)MainTableControl.DG_1.SelectedItem == null)
            {
                MessageBox.Show("행을 선택해주세요");
                return "";
            }

            if ((DataRowView)MainTableControl.DG_1.SelectedItems[0] == null)
            {
                MessageBox.Show("행을 선택해주세요");
                return "";
            }

            DataRowView row = (DataRowView)MainTableControl.DG_1.SelectedItems[0];


            string product_info_id = row["id"].ToString();

            return product_info_id;
        }

        //삭제 
        private void btn_Product_del_Click(object sender, RoutedEventArgs e)
        {
            string product_info_id = getGridSelectedIndex();
            if (product_info_id == null)
            {
                MessageBox.Show("행을 선택해주세요");
                return;

            }

            if (Func_Util.YesOrNoMSGBOX("삭제", "삭제하시겠습니까?"))
            {

                string del_sql = "delete from ms_product_info_output_cancel_log where id = " + product_info_id;
                Func_MySQL.instance.SetDATA(del_sql).ExecuteNonQuery();

                MainTableControl.refreshThisPages();

            }
        }



        public void refreshMainTabControl()
        {
            //MainTableControl.refreshThisPages();

            MainTableControl.Refresh_pages(1, MainSQL);

        }





        //초기화 
        private void btn_Search_Product_Init_Click(object sender, RoutedEventArgs e)
        {
            uC_txt_search_output_name.txt_search.Text = "";
            uC_txt_search_output_trade_name.txt_search.Text = "";
        }


        //전체보기 
        private void btn_Search_Product_All_Click(object sender, RoutedEventArgs e)
        {
            MainTableControl.Refresh_pages(1, MainSQL);
        }
        

        //검색 
        private void btn_Search_Product_Click(object sender, RoutedEventArgs e)
        {
            string search_sql = MainSQL + GetSearchSQL();
            MainTableControl.Refresh_pages(1, search_sql);
        }
    }
}
